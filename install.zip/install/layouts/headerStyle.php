<!-- Bootstrap Css -->
<link href="public/css/bootstrap-dark.min.css" id="bootstrap-style" rel="stylesheet" type="text/css"/>
<!-- Icons Css -->
<link href="public/css/icons.min.css" rel="stylesheet" type="text/css"/>
<!-- App Css-->
<link href="public/css/app-dark.min.css" id="app-style" rel="stylesheet" type="text/css"/>
</head>